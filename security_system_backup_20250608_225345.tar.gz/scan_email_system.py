import smtplib
import json
import os
import sys
import logging
from contextlib import closing

# --- 診断対象のモジュールを安全にインポート ---
# プロジェクトルートをパスに追加
sys.path.append('.') 
try:
    from weather_forecast import get_weather_forecast
    WEATHER_AVAILABLE = True
except ImportError:
    WEATHER_AVAILABLE = False

try:
    from season_detector import get_current_season
    SEASON_AVAILABLE = True
except ImportError:
    SEASON_AVAILABLE = False
    
# --- 診断用ロガー設定 ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('EmailSystemScanner')


def print_header(title):
    print("\n" + "="*80)
    print(f"🔬 {title}")
    print("="*80)

def check(description, function_to_run):
    """テストを実行し、成功/失敗を表示するヘルパー関数"""
    try:
        result = function_to_run()
        if result is not False: # Falseが返された場合を失敗とみなす
            print(f"  ✅ {description}: 正常")
            return True
        else:
            print(f"  ❌ {description}: 失敗 (関数がFalseを返しました)")
            return False
    except Exception as e:
        print(f"  ❌ {description}: 失敗 (例外発生)")
        logger.error(f"{description}で例外発生: {e}", exc_info=True)
        return False

def main():
    print("🚀 メールシステム 精密検査スキャナー起動...")

    # --- テスト1: 設定ファイルの検証 ---
    print_header("1. 設定ファイルの検証")
    def test_config_loading():
        global settings
        if not os.path.exists('settings.json'):
            logger.error("settings.jsonが見つかりません。")
            return False
        with open('settings.json', 'r', encoding='utf-8') as f:
            settings = json.load(f)
        
        email_config = settings.get('notification', {}).get('email', {})
        if not email_config:
            logger.error('設定ファイル内に "notification.email" のセクションが見つかりません。')
            return False
        
        required_keys = ['smtp_server', 'smtp_port', 'smtp_user', 'smtp_password', 'email_sender', 'email_recipients']
        if not all(key in email_config for key in required_keys):
            logger.error(f'メール設定に必要なキーが不足しています。必須: {required_keys}')
            return False
        return True
    
    config_ok = check("設定ファイルの読み込みと必須キーの存在確認", test_config_loading)
    if not config_ok:
        print("\n❌ 設定ファイルに問題があるため、以降のテストを中止します。")
        return

    # --- テスト2: 依存関係の確認 ---
    print_header("2. 依存関係の確認")
    check("天気予報モジュールの認識", lambda: WEATHER_AVAILABLE)
    check("季節判定モジュールの認識", lambda: SEASON_AVAILABLE)

    # --- テスト3: データ収集の模擬テスト ---
    print_header("3. データ収集の模擬テスト")
    check("天気予報データの収集シミュレーション", lambda: get_weather_forecast() is not None if WEATHER_AVAILABLE else "SKIPPED")

    # --- テスト4: メール本文の生成テスト ---
    print_header("4. メール本文の生成テスト")
    def test_content_generation():
        # このテストのためにemail_capsule.pyからロジックを借用
        from email_capsule import EnhancedEmailNotifier
        notifier = EnhancedEmailNotifier(settings)
        # 本文生成に必要なデータをダミーで作成
        dummy_weather = {'today': {'weather': '快晴'}}
        dummy_reco = {'charge_current': 50, 'charge_time': 60, 'soc': 50}
        content = notifier._generate_email_content(dummy_weather, dummy_reco)
        return content and "HANAZONOシステム" in content
    
    check("メール本文の生成ロジック", test_content_generation)

    # --- テスト5: SMTPサーバー接続テスト ---
    print_header("5. SMTPサーバー接続テスト（実際の送信はしません）")
    def test_smtp_connection():
        email_config = settings.get('notification', {}).get('email', {})
        server = email_config.get('smtp_server')
        port = email_config.get('smtp_port')
        user = email_config.get('smtp_user')
        password = os.path.expandvars(email_config.get('smtp_password', ''))

        if not password or password == "${SMTP_PASSWORD}":
            print("  ⚠️ SMTPパスワードが環境変数に設定されていないため、テストをスキップします。")
            return "SKIPPED"
        
        with closing(smtplib.SMTP(server, port, timeout=10)) as s:
            s.starttls()
            s.login(user, password)
        # 接続とログインが成功すればOK
        return True

    check("SMTPサーバーへの接続と認証", test_smtp_connection)

    print("\n" + "="*80)
    print("✅ メールシステム精密検査完了")
    print("="*80)

if __name__ == "__main__":
    main()
