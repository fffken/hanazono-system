import requests
import json
import datetime
from config import WEATHER_API_URL, WARNING_API_URL, TYPHOON_API_URL

def get_weather_forecast():
    """
    気象庁APIから天気予報、警報・注意報、台風情報を取得する
    戻り値: 今日から3日分の天気予報と警報・注意報、台風情報のディクショナリ
    """
    try:
        response = requests.get(WEATHER_API_URL)
        if response.status_code != 200:
            print(f'天気予報APIエラー: ステータスコード {response.status_code}')
            return None
        data = response.json()
        forecasts = data[0]['timeSeries'][0]['areas'][0]['weathers']
        dates = data[0]['timeSeries'][0]['timeDefines']
        weather_data = {'days': []}
        current_date = datetime.datetime.now()
        for i in range(min(len(dates), 3)):
            if i < len(dates):
                forecast_date = datetime.datetime.strptime(dates[i].split('T')[0], '%Y-%m-%d')
                date_str = forecast_date.strftime('%Y-%m-%d')
                day_name = ['月', '火', '水', '木', '金', '土', '日'][forecast_date.weekday()]
                date_display = f'{forecast_date.month}月{forecast_date.day}日({day_name})'
            else:
                date_str = '不明'
                date_display = '不明'
            weather = 'データなし'
            if i < len(forecasts) and forecasts[i] != '':
                weather = forecasts[i]
            is_today = i == 0
            is_tomorrow = i == 1
            is_day_after_tomorrow = i == 2
            day_data = {'date': date_str, 'display_date': date_display, 'weather': weather, 'is_today': is_today, 'is_tomorrow': is_tomorrow, 'is_day_after_tomorrow': is_day_after_tomorrow}
            weather_data['days'].append(day_data)
        if len(weather_data['days']) > 0:
            weather_data['today'] = weather_data['days'][0]
        else:
            weather_data['today'] = {'date': current_date.strftime('%Y-%m-%d'), 'display_date': f'{current_date.month}月{current_date.day}日', 'weather': 'データなし', 'is_today': True, 'is_tomorrow': False, 'is_day_after_tomorrow': False}
        if len(weather_data['days']) > 1:
            weather_data['tomorrow'] = weather_data['days'][1]
        else:
            tomorrow = current_date + datetime.timedelta(days=1)
            weather_data['tomorrow'] = {'date': tomorrow.strftime('%Y-%m-%d'), 'display_date': f'{tomorrow.month}月{tomorrow.day}日', 'weather': 'データなし', 'is_today': False, 'is_tomorrow': True, 'is_day_after_tomorrow': False}
        if len(weather_data['days']) > 2:
            weather_data['day_after_tomorrow'] = weather_data['days'][2]
        else:
            day_after_tomorrow = current_date + datetime.timedelta(days=2)
            weather_data['day_after_tomorrow'] = {'date': day_after_tomorrow.strftime('%Y-%m-%d'), 'display_date': f'{day_after_tomorrow.month}月{day_after_tomorrow.day}日', 'weather': 'データなし', 'is_today': False, 'is_tomorrow': False, 'is_day_after_tomorrow': True}
        try:
            warning_response = requests.get(WARNING_API_URL)
            if warning_response.status_code == 200:
                warning_data = warning_response.json()
                warnings = []
                if warning_data and 'areaTypes' in warning_data:
                    for area_type in warning_data['areaTypes']:
                        for area in area_type.get('areas', []):
                            area_name = area.get('name', '')
                            warnings_list = area.get('warnings', [])
                            for warning in warnings_list:
                                warning_kind = warning.get('kind', {})
                                warning_name = warning_kind.get('name', '')
                                warning_status = warning_kind.get('status', '')
                                if warning_name and warning_status != '解除':
                                    warnings.append({'area': area_name, 'name': warning_name, 'status': warning_status})
                weather_data['warnings'] = warnings
            else:
                print(f'警報・注意報APIエラー: ステータスコード {warning_response.status_code}')
                weather_data['warnings'] = []
        except Exception as e:
            print(f'警報・注意報取得エラー: {str(e)}')
            weather_data['warnings'] = []
        try:
            typhoon_response = requests.get(TYPHOON_API_URL)
            if typhoon_response.status_code == 200:
                typhoon_data = typhoon_response.json()
                typhoons = []
                if typhoon_data:
                    for typhoon_id, typhoon_info in typhoon_data.items():
                        if typhoon_id.startswith('typhoon'):
                            try:
                                typhoon_name = typhoon_info.get('name', '')
                                typhoon_en_name = typhoon_info.get('en_name', '')
                                typhoon_number = typhoon_info.get('number', '')
                                latest_info = None
                                for info in typhoon_info.get('info', []):
                                    if not latest_info or info.get('datetime', '') > latest_info.get('datetime', ''):
                                        latest_info = info
                                if latest_info:
                                    location = latest_info.get('location', {})
                                    lat = location.get('lat', 0)
                                    lon = location.get('lon', 0)
                                    intensity = latest_info.get('intensity', '')
                                    pressure = latest_info.get('pressure', '')
                                    typhoon_obj = {'number': typhoon_number, 'name': typhoon_name, 'en_name': typhoon_en_name, 'lat': lat, 'lon': lon, 'intensity': intensity, 'pressure': pressure}
                                    typhoons.append(typhoon_obj)
                            except Exception as e:
                                print(f'台風情報解析エラー: {str(e)}')
                weather_data['typhoons'] = typhoons
            else:
                print(f'台風情報APIエラー: ステータスコード {typhoon_response.status_code}')
                weather_data['typhoons'] = []
        except Exception as e:
            print(f'台風情報取得エラー: {str(e)}')
            weather_data['typhoons'] = []
        return weather_data
    except Exception as e:
        print(f'天気予報取得エラー: {str(e)}')
        return None