import smtplib
import json
import os
import sys
import logging
from contextlib import closing
import traceback

# --- ロガー設定 ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('EmailModuleScanner')

def print_header(title):
    print("\n" + "="*80)
    print(f"🔬 {title}")
    print("="*80)

def check(description, function_to_run):
    """テストを実行し、成功/失敗/スキップを表示するヘルパー関数"""
    print(f"- {description}: ", end="")
    try:
        result = function_to_run()
        if result is True:
            print("✅ 正常")
            return True
        elif result == "SKIPPED":
            print("⚠️ スキップ")
            return True # スキップは失敗ではない
        else:
            print("❌ 失敗")
            return False
    except Exception as e:
        print("❌ 失敗 (例外発生)")
        logger.error(f"{description}で例外発生:\n{traceback.format_exc()}")
        return False

def main():
    print("🚀 メールシステム単体 精密検査スキャナー起動...")
    
    # --- 依存モジュールのインポート ---
    sys.path.append('.') 
    try:
        from email_notifier import EnhancedEmailNotifier
        from lvyuan_collector import LVYUANCollector
        from weather_forecast import get_weather_forecast
    except ImportError as e:
        print(f"\n❌ 致命的エラー: 必要なモジュールのインポートに失敗しました: {e}")
        return

    # --- テストの実行 ---
    print_header("1. 設定ファイルの検証")
    def test_config():
        global settings
        with open('settings.json', 'r', encoding='utf-8') as f:
            settings = json.load(f)
        email_config = settings.get('notification', {}).get('email', {})
        required = ['smtp_server', 'smtp_port', 'smtp_user', 'smtp_password']
        return all(key in email_config for key in required)
    
    config_ok = check("設定ファイルの読み込みと必須キーの存在確認", test_config)
    if not config_ok:
        print("\n❌ 設定ファイルに問題があるため、一部テストをスキップします。")

    print_header("2. データソース接続テスト")
    check("天気予報データ収集関数の実行", lambda: isinstance(get_weather_forecast(), dict))
    check("LVYUANコレクターの初期化とデータ収集", lambda: LVYUANCollector().collect_data() is not None)

    print_header("3. SMTPサーバー接続テスト（実際の送信はしません）")
    def test_smtp():
        if not config_ok: return "SKIPPED"
        email_config = settings.get('notification', {}).get('email', {})
        password = os.path.expandvars(email_config.get('smtp_password', ''))
        if not password or password == "${SMTP_PASSWORD}": return "SKIPPED"
        
        with closing(smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port'], timeout=10)) as s:
            s.starttls()
            s.login(email_config['smtp_user'], password)
        return True

    check("SMTPサーバーへの接続と認証", test_smtp)

    print("\n" + "="*80)
    print("✅ メールシステム精密検査完了")
    print("="*80)

if __name__ == "__main__":
    main()
