class EmailNotifier:

    def _parse_weather_components(self, weather_text):
        """天気文字列から各成分を抽出する"""
        if not weather_text or weather_text == 'データなし':
            return ['データなし']
        components = []
        for delimiter in [' のち ', 'のち', ' 後 ', '後']:
            if delimiter in weather_text:
                components = weather_text.split(delimiter)
                break
        if not components:
            components = [weather_text]
        return components

    def _format_weather_emojis(self, weather_text):
        """天気情報を絵文字の連結に変換"""
        if not weather_text or weather_text == 'データなし':
            return '🌐'
        components = self._parse_weather_components(weather_text)
        emojis = [self._get_weather_emoji(comp.strip()) for comp in components]
        return '→'.join(emojis)

    def _format_weather_line(self, weather_text):
        """天気情報を2行フォーマットに整形"""
        if not weather_text or weather_text == 'データなし':
            return '🌐\nデータなし'
        emoji_text = self._format_weather_emojis(weather_text)
        display_text = weather_text
        for term in [' のち ', 'のち', ' 後 ', '後']:
            display_text = display_text.replace(term, '→')
        return f'{emoji_text}\n{display_text}'