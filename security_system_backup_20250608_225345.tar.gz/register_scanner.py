import sys
import time
import json
import os
from pysolarmanv5 import PySolarmanV5
from lvyuan_registers import REGISTER_GROUPS

def scan_registers(ip, serial_number, start_addr, count, description):
    print(f'\n{description}レジスタ ({hex(start_addr)}～{hex(start_addr + count - 1)}) 読み取り試行...')
    try:
        modbus = PySolarmanV5(address=ip, serial=serial_number, port=8899, mb_slave_id=1, verbose=False)
        values = modbus.read_holding_registers(start_addr, count)
        print(f'読み取り成功: {values}')
        non_zero_registers = {}
        for i, value in enumerate(values):
            if value != 0:
                addr = start_addr + i
                non_zero_registers[addr] = value
                print(f'  レジスタ {hex(addr)}: {value}')
        return (True, non_zero_registers)
    except Exception as e:
        print(f'読み取りエラー: {e}')
        return (False, {})

def save_results(discovered_registers):
    if not discovered_registers:
        return
    data_dir = os.path.join(os.path.expanduser('~'), 'lvyuan_solar_control', 'data')
    os.makedirs(data_dir, exist_ok=True)
    timestamp = time.strftime('%Y%m%d-%H%M%S')
    filename = os.path.join(data_dir, f'discovered_registers_{timestamp}.json')
    with open(filename, 'w') as f:
        json_data = {}
        for addr in sorted(discovered_registers.keys()):
            json_data[hex(addr)] = discovered_registers[addr]
        json.dump(json_data, f, indent=2)
    print(f'\n結果を {filename} に保存しました。')

def main():
    if len(sys.argv) != 3:
        print(f'使用法: {sys.argv[0]} <IPアドレス> <シリアル番号>')
        sys.exit(1)
    ip = sys.argv[1]
    serial_number = int(sys.argv[2])
    discovered_registers = {}
    for group in REGISTER_GROUPS:
        success, registers = scan_registers(ip, serial_number, group['start'], group['count'], group['name'])
        if success:
            discovered_registers.update(registers)
        time.sleep(1)
    important_registers = [(57345, 1, 'PV充電電流設定'), (57866, 1, '最大充電電流'), (57361, 1, '均等充電時間'), (57362, 1, 'ブースト充電時間'), (57363, 1, '均等充電間隔'), (57379, 1, '均等充電タイムアウト'), (57359, 1, '充電・放電カットオフSOC')]
    for addr, count, desc in important_registers:
        success, registers = scan_registers(ip, serial_number, addr, count, desc)
        if success:
            discovered_registers.update(registers)
        time.sleep(1)
    save_results(discovered_registers)
    print('\nスキャン完了！')
if __name__ == '__main__':
    main()