import requests
import json
import datetime
import re
from config import WEATHER_API_URL, WARNING_API_URL, TYPHOON_API_URL

def get_weather_forecast():
    """
    気象庁APIから天気予報、警報・注意報、台風情報を取得する
    戻り値: 今日から3日分の天気予報と警報・注意報、台風情報のディクショナリ
    """
    weather_data = {'days': [], 'warnings': [], 'typhoons': []}
    current_date = datetime.datetime.now()

    # --- 天気予報の取得 ---
    try:
        response = requests.get(WEATHER_API_URL)
        if response.status_code != 200:
            print(f'天気予報APIエラー: ステータスコード {response.status_code}')
            return None
        data = response.json()
        
        forecasts = data[0]['timeSeries'][0]['areas'][0]['weathers']
        dates = data[0]['timeSeries'][0]['timeDefines']

        for i in range(min(len(dates), 3)):
            forecast_date = datetime.datetime.strptime(dates[i].split('T')[0], '%Y-%m-%d')
            date_str = forecast_date.strftime('%Y-%m-%d')
            day_name = ['月', '火', '水', '木', '金', '土', '日'][forecast_date.weekday()]
            date_display = f'{forecast_date.month}月{forecast_date.day}日({day_name})'
            weather = forecasts[i] if i < len(forecasts) and forecasts[i] != '' else 'データなし'
            
            day_data = {
                'date': date_str, 
                'display_date': date_display, 
                'weather': weather,
                'is_today': i == 0,
                'is_tomorrow': i == 1,
                'is_day_after_tomorrow': i == 2
            }
            weather_data['days'].append(day_data)

    except Exception as e:
        print(f'天気予報取得で致命的なエラー: {str(e)}')
        # 失敗した場合でも、3日分の空のデータ構造を保証する
        for i in range(3):
            date_obj = current_date + datetime.timedelta(days=i)
            day_name = ['月', '火', '水', '木', '金', '土', '日'][date_obj.weekday()]
            weather_data['days'].append({
                'date': date_obj.strftime('%Y-%m-%d'),
                'display_date': f'{date_obj.month}月{date_obj.day}日({day_name})',
                'weather': '取得失敗',
                'is_today': i == 0, 'is_tomorrow': i == 1, 'is_day_after_tomorrow': i == 2
            })

    # --- 警報・注意報の取得 ---
    try:
        warning_response = requests.get(WARNING_API_URL)
        if warning_response.status_code == 200:
            warning_data = warning_response.json()
            if warning_data and 'areaTypes' in warning_data:
                for area_type in warning_data['areaTypes']:
                    for area in area_type.get('areas', []):
                        for warning in area.get('warnings', []):
                            if warning.get('status') != '解除':
                                weather_data['warnings'].append({
                                    'area': area.get('name', ''),
                                    'name': warning.get('kind', {}).get('name', ''),
                                    'status': warning.get('status', '')
                                })
    except Exception as e:
        print(f'警報・注意報取得エラー: {str(e)}')

    # --- 台風情報の取得 ---
    try:
        typhoon_response = requests.get(TYPHOON_API_URL)
        if typhoon_response.status_code == 200:
            typhoon_data = typhoon_response.json()
            if typhoon_data:
                for typhoon_id, typhoon_info in typhoon_data.items():
                    if typhoon_id.startswith('typhoon') and typhoon_info.get('info'):
                        latest_info = max(typhoon_info['info'], key=lambda x: x.get('datetime', ''))
                        weather_data['typhoons'].append({
                            'name': typhoon_info.get('name', ''),
                            'number': typhoon_info.get('number', ''),
                            'intensity': latest_info.get('intensity', ''),
                            'pressure': latest_info.get('pressure', '')
                        })
    except Exception as e:
        print(f'台風情報取得エラー: {str(e)}')

    # --- 気温の抽出（全ての日に適用） ---
    def extract_temperature(weather_text):
        """天気テキストから気温を抽出または推定"""
        if not isinstance(weather_text, str): return 'N/A'
        temps = re.findall(r'(\d+)', weather_text)
        temps = [int(t) for t in temps]
        if len(temps) >= 2:
            return f'{min(temps)}℃ 〜 {max(temps)}℃'
        elif len(temps) == 1:
            return f'{temps[0]}℃'
        # 推定ロジックは参考情報として保持
        return 'N/A' # 推定は行わない

    for day in weather_data.get('days', []):
        day['temperature'] = extract_temperature(day.get('weather'))

    # today, tomorrow, day_after_tomorrowキーを確実に設定
    weather_data['today'] = weather_data['days'][0] if len(weather_data['days']) > 0 else {}
    weather_data['tomorrow'] = weather_data['days'][1] if len(weather_data['days']) > 1 else {}
    weather_data['day_after_tomorrow'] = weather_data['days'][2] if len(weather_data['days']) > 2 else {}

    return weather_data

if __name__ == '__main__':
    # このファイルが直接実行された場合のテストコード
    print("--- 天気予報モジュール単体テスト ---")
    forecast_data = get_weather_forecast()
    if forecast_data:
        print("\n[今日の天気]")
        print(json.dumps(forecast_data.get('today'), indent=2, ensure_ascii=False))
        
        print("\n[警報・注意報]")
        if forecast_data.get('warnings'):
            for warn in forecast_data['warnings']:
                print(f"- {warn['area']}: {warn['name']} ({warn['status']})")
        else:
            print("発表されていません。")

        print("\n[台風情報]")
        if forecast_data.get('typhoons'):
            for typhoon in forecast_data['typhoons']:
                print(f"- 台風{typhoon['number']}号 ({typhoon['name']})")
        else:
            print("発表されていません。")
        
        print("\n--- テスト成功 ---")
    else:
        print("\n--- テスト失敗 ---")
