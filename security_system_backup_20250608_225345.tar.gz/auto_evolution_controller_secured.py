#!/usr/bin/env python3
"""
Security Wrapper for scripts/auto_evolution_controller.sh
自動生成セキュリティラッパー - 直接実行禁止
"""
import json
import hashlib
from datetime import datetime
from pathlib import Path

def verify_ticket():
    """チケット検証"""
    ticket_file = Path("security_clearance/execution_tickets/ticket_auto_evolution_controller_053dddec18d93dca.json")
    
    if not ticket_file.exists():
        print("❌ 実行チケットが見つかりません")
        return False
    
    with open(ticket_file, 'r') as f:
        ticket_data = json.load(f)
    
    # 有効期限確認
    expiry = datetime.fromisoformat(ticket_data['expiry_timestamp'])
    if datetime.now() > expiry:
        print("❌ 実行チケットが期限切れです")
        return False
    
    # 実行回数確認
    if ticket_data['execution_count'] >= ticket_data['max_executions']:
        print("❌ 実行回数上限に達しています")
        return False
    
    # スクリプト整合性確認
    with open("scripts/auto_evolution_controller.sh", 'r') as f:
        current_hash = hashlib.sha256(f.read().encode()).hexdigest()
    
    if current_hash != ticket_data['script_hash']:
        print("❌ スクリプトが変更されています。再検査が必要です")
        return False
    
    # 実行回数更新
    ticket_data['execution_count'] += 1
    with open(ticket_file, 'w') as f:
        json.dump(ticket_data, f, indent=2)
    
    print(f"✅ セキュリティチケット検証成功 (残り{ticket_data['max_executions'] - ticket_data['execution_count']}回)")
    return True

def main():
    """メイン実行（セキュリティチェック後）"""
    if not verify_ticket():
        exit(1)
    
    print(f"🔐 セキュアモードで {script_path} を実行")
    
    # 元スクリプト実行
    import subprocess
    result = subprocess.run(['python3', 'scripts/auto_evolution_controller.sh'], capture_output=True, text=True)
    
    print(result.stdout)
    if result.stderr:
        print(f"エラー: {result.stderr}")
    
    return result.returncode

if __name__ == "__main__":
    exit(main())
